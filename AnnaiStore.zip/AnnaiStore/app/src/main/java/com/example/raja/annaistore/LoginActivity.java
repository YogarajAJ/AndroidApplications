package com.example.raja.annaistore;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener
{

    private ProgressDialog progressDialog;

    private FirebaseAuth mAuth;

    private EditText emailBox,passwordBox;
    private Button loginButton;
    private CheckBox rememberMe;
    private TextView loginToReg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        emailBox = findViewById(R.id.emailEditText);
        passwordBox = findViewById(R.id.passwordEditText);

        loginButton=findViewById(R.id.loginButton);

        rememberMe = findViewById(R.id.checkBox);

        loginToReg=findViewById(R.id.loginToRegTextButton);


        mAuth = FirebaseAuth.getInstance();

        loginButton.setOnClickListener(this);
        loginToReg.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v == loginButton)
            login();
        if(v == loginToReg)
            changeActivity();
    }

    private void changeActivity() {

    }

    private void login() {


        String email = emailBox.getText().toString().trim();
        String password = passwordBox.getText().toString().trim();

        if (progressDialog == null) {
            progressDialog = createProgressDialog(LoginActivity.this);
            progressDialog.show();
        }
        else {
            progressDialog.show();
        }
        progressDialog = new ProgressDialog(this);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Login Successful.",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            progressDialog.dismiss();
                            // If sign in fails, display a message to the user.
                            Toast.makeText(getApplicationContext(), "Login failed.",
                                    Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });
    }

    public static ProgressDialog createProgressDialog(Context context) {
        ProgressDialog dialog = new ProgressDialog(context);
        try {
            dialog.show();
        } catch (WindowManager.BadTokenException e) {

        }
        dialog.setCancelable(false);
        dialog.getWindow()
                .setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.progressdialog);
        // dialog.setMessage(Message);
        return dialog;
    }
}
